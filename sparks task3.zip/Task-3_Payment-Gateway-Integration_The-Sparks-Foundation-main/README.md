# Task 3_Payment Gateway Integration_The Sparks Foundation
 
The following objectives were completed:

-> To create a simple website where payment gateway is integrated.

-> On the homepage, a basic button for donation should be present. The user can choose the amount to donate and the method of payment (credit card, Paypal, etc.) on the payment page after clicking the donate button.

-> Once the payment is done and invoice will be generated and email will be sent to the user for the payment received. The invoice will contain the amount. 
